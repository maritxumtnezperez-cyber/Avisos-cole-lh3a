# Avisos Cole · LH3A
Aplicación PWA para una clase. Una sola persona publica; las familias no necesitan cuenta.
