self.addEventListener('push',e=>{const d=e.data?.json()||{};e.waitUntil(self.registration.showNotification(d.title||'Avisos Cole',{body:d.body||'Nuevo aviso',icon:'/logo.png'}))});
